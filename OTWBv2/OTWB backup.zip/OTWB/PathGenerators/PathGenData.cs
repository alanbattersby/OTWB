﻿using Geometric_Chuck;
using Geometric_Chuck.Common;
using Geometric_Chuck.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace OTWB.PathGenerators
{
    [XmlInclude(typeof(Geometric_Chuck.BazelyChuck))]
    [XmlInclude(typeof(Geometric_Chuck.RossData))]
    [XmlInclude(typeof(Geometric_Chuck.WheelsData))]
    [XmlInclude(typeof(Geometric_Chuck.Spindle.Barrel))]
    public class PathGenData : BindableBase, PathData
    {
      
        [XmlIgnore]
        public string Name
        {
            get { return string.Format("{0}#{1}", PathType, PatternIndex); }
        }

        PatternType _ptype;
        public PatternType PathType
        {
            get { return _ptype; }
            set { SetProperty(ref _ptype, value); }
        }

        int _patternindx;
        public int PatternIndex
        {
            get { return _patternindx; }
            set { SetProperty(ref _patternindx, value); }
        }

        double _maxTurns;
        public double SuggestedMaxTurns
        {
            get { return _maxTurns; }
            set { SetProperty(ref _maxTurns, value); }
        }

        public PathGenData(PatternType typ, int indx, int turns)
        {
            PathType = typ;
            PatternIndex = indx;
            SuggestedMaxTurns = turns;
        }

        public PathGenData() : this(PatternType.NONE, -1,1) { }
    }
}
