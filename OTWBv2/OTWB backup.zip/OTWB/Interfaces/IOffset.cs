﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Geometric_Chuck.Interfaces
{
    interface IOffset
    {
        object Value { get; set; }
    }
}
