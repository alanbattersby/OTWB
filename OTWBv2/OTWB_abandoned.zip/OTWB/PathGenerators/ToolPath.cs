﻿using OTWB.Coordinates;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.Foundation;
using Windows.UI;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Shapes;
using System.Xml.Serialization;
using Geometric_Chuck;
using System.Collections.ObjectModel;
using OTWB.Extensions;

namespace OTWB.PathGenerators
{
  
    public class PathFragment 
    {
        private Extent2D _extent;
        public Extent2D Extent
        {
            get { return _extent; }
        }

        List<ICoordinate> _items;
        public List<ICoordinate> Items
        {
            get { return _items; }
            set { _items = value; }
        }

        bool _closed;
        public bool IsClosed
        {
            get { return _closed; }
            set { _closed = value; }
        }

        public PathFragment()
        {
            _extent = new Extent2D();
            _items = new List<ICoordinate>();
            _closed = false;
        }

        public PathFragment(Windows.UI.Xaml.Media.PointCollection pointCollection)
        {
            _extent = new Extent2D();
            _items = new List<ICoordinate>();
            _closed = pointCollection[0] == pointCollection[pointCollection.Count - 1];
            foreach (Point p in pointCollection)
                Add(new Cartesian(p.X, p.Y, 0));
        }

        public void  Add(ICoordinate item)
        {
            _items.Add(item);
            if (_extent == null)
                _extent = new Extent2D();
            _extent.Update(item);
            _closed = _items[0] == item;
        }

        public void Clear()
        {
            this.Clear();
            _extent.Clear();
            _closed = false;
        }

        public PathFragment ToCartesian()
        {
            PathFragment f = new PathFragment();
            for (int indx = 0; indx < Items.Count; indx++)
            {
                f.Add(Items[indx].toCartesian);
            }
            return f;
        }
        public void ToSpherical()
        {
            for (int indx = 0; indx < Items.Count; indx++)
            {
                Items[indx] = Items[indx].toSpherical;
            }
        }
        public PathFragment ToCylindrical()
        {
            PathFragment f = new PathFragment();
            for (int indx = 0; indx < Items.Count; indx++)
            {
                f.Add(Items[indx].toCylindrical);
            }
            return f;
        }

        public PointCollection Points
        {
            get
            {
                PointCollection pc = new PointCollection();
                foreach (ICoordinate c in Items)
                {
                    Cartesian cc = (Cartesian)c.toCartesian;
                    pc.Add(new Point(cc.X,cc.Y));
                }
                return pc;
            }
            
        }
        public PathFragment Offsets 
        {
            get
            {
                PathFragment offs = new PathFragment();
                for (int indx = 1; indx < this.Items.Count; indx++)
                {
                    offs.Add((ICoordinate)_items[indx +1].Difference(_items[indx]));
                }
                if (_closed)
                    offs.Add(_items[0].Difference( _items[_items.Count - 1]));
                return offs;
            }
        }

        public void Scale(double sfx, double sfy, double sfz)
        {
            for (int indx = 0; indx < Items.Count; indx++)
            {
                Items[indx].Scale(sfx,sfy,sfz); 
            }
        }

        public PathFragment TransformBy(PathTransform t)
        {
            PathFragment pf = new PathFragment();
            foreach (ICoordinate c in this.Items)
            {
                ICoordinate cc = c.Copy;
                cc.Scale(t.ScaleX, t.ScaleY,1);
                cc.Rotate(t.Rotation);
                cc.Translate(t.TranslateX, t.TranslateY, t.TranslateZ);
                pf.Add(cc);
            }

            return pf;
        }

        public void Translate(double x, double y, double z)
        {
            for (int indx = 0; indx < Items.Count; indx++)
            {
                Items[indx].Translate(x,y,z); 
            }
        }

        public void Rotate(double angle)
        {
            for (int indx = 0; indx < Items.Count; indx++)
            {
                Items[indx].Rotate(angle);
            }
        }
    }

    public class ToolPath : ObservableCollection<PathFragment> 
    {
        public event EventHandler ToolPathChanged;

        public string PatternName { get; set; }

        PathTransform  Pathtransform { get ; set; }

        public ToolPath() : base() 
        {
            Pathtransform = new PathTransform();
            Pathtransform.PropertyChanged += Pathtransform_PropertyChanged;
        
        }

        void Pathtransform_PropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            if (ToolPathChanged != null)
                ToolPathChanged(this, new EventArgs());
        }

        public ToolPath(PointCollection pc)
            : this()
        {
            PathFragment f = new PathFragment(pc);
            this.Add(f);
        }

         /// <summary>
        /// If only one fragment then assume it is a polygon
        /// </summary>
        [XmlIgnore]
        public Shape Visual
        {
            get
            {
                return (this.Count == 1) ? GenPoly() : GenPath();
            }

        }

        private Shape GenPath()
        {
            Polygon poly = new Polygon();

            return poly;
        }

        private Shape GenPoly()
        {
            Polygon poly = new Polygon();
            poly.Stroke = new SolidColorBrush(Color.FromArgb(255, 255, 0, 0));
            CompositeTransform tf = new CompositeTransform();
            tf.ScaleX = Pathtransform.ScaleX;
            tf.Rotation = Pathtransform.Rotation;
            tf.TranslateX = Pathtransform.TranslateX;
            tf.TranslateY = Pathtransform.TranslateY;
           
            poly.RenderTransform = tf;
           
            poly.Points = this[0].Points;
            return poly;
        }

        public ToolPath TransformedPath
        {
            get
            {
                ToolPath tp = new ToolPath();
                foreach (PathFragment pf in this)
                {
                    tp.Add(pf.TransformBy(Pathtransform));
                }
                return tp;
            }
        }

        void ScaleBy (double sfx, double sfy, double sfz)
        {
            for (int indx = 0; indx < this.Count; indx++)
                this[indx].Scale(sfx,sfy,sfz);
        }

        void Translate(double x, double y, double z)
        {
            for (int indx = 0; indx < this.Count; indx++)
                this[indx].Translate(x,y,z);
        }

        public void Translate(Point c)
        {
            for (int indx = 0; indx < this.Count; indx++)
                this[indx].Translate(c.X, c.Y, 0);      
        }
   
        public void Rotate(double angle)
        {
            for (int indx = 0; indx < this.Count; indx++)
                foreach (ICoordinate cc in this[indx].Items)
                {
                    Cylindrical c = (Cylindrical)cc.toCylindrical;
                    c.Angle += angle;
                }      
        }

        public Extent2D _extent;
        public void CalculateExtent()
        {
            _extent = new Extent2D(double.MaxValue, double.MinValue, double.MaxValue, double.MinValue);
            foreach (PathFragment f in this)
                _extent.Merge(f.Extent);
        }
        public Extent2D Extent
        {
            get { return _extent; }
        }

        public int TotalPointCount
        {
            get
            {
                int tot = 0;
                foreach (PathFragment f in this)
                    tot += f.Items.Count;

                return tot;
            }
        }

        public ToolPath OffsetPath
        {
            get
            {
                ToolPath tp = new ToolPath();
                foreach (PathFragment f in this)
                {
                    tp.Add(f.Offsets);
                }

                return tp;
            }
        }

        public ToolPath CylindricalPath
        {
            get
            {
                ToolPath tp = new ToolPath();
                foreach (PathFragment f in this)
                {
                    tp.Add(f.ToCylindrical());
                }

                return tp;
            }
        }
    }
}
